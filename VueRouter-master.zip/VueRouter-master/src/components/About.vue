<template>
  <h1>About us</h1>
</template>

<script>
  export default {

  }
</script>
