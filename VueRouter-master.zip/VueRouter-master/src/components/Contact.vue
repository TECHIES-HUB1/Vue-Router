<template>
<h1>Contact us</h1>
</template>

<script>
  export default {

  }
</script>
