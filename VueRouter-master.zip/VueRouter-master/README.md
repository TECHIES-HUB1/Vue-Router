Clone the repository
Go to the project folder and install the dependencies via "npm install"
Start the webpack server by "npm start"
Go to the URL: http://localhost:3000

If you want to understand the vue-router then follow this URL: http://appdividend.com/2017/08/02/how-to-use-vue-router
